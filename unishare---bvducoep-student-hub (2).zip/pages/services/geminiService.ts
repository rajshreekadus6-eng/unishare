
import { GoogleGenAI, Type } from "@google/genai";
import { MarketplaceItem, HonestReview } from "../types";

// Initialize Gemini API client using the environment API key
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface VideoInspectionResult {
  item_name: string;
  category: string;
  quality_grade: 'A' | 'B' | 'C';
  estimated_price: number;
  review: HonestReview;
  carbonSaved: number;
}

export interface GroundedResponse {
  text: string;
  sources: { title: string; uri: string }[];
}

/**
 * High-Precision Technical Audit for engineering hardware.
 * Uses gemini-3-pro-preview for advanced vision reasoning.
 */
export const analyzeTechnicalCondition = async (base64Images: string[]): Promise<VideoInspectionResult> => {
  try {
    const ai = getAI();
    const imageParts = base64Images.map(data => ({
      inlineData: {
        mimeType: 'image/jpeg',
        data,
      },
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          ...imageParts,
          {
            text: `You are the "Master Engineering Auditor" for UniShare BVDUCOEP.
            Inspect this hardware tool. Look for burnt components, bent pins, or wear.
            Return ONLY a JSON object:
            {
              "item_name": "Specific Model Name",
              "category": "Engineering Graphics Kits" | "Drawing Sheet Containers" | "Vehicle Sensors" | "Hardware/Tools" | "Electronic Components" | "General Student Essentials",
              "quality_grade": "A" | "B" | "C",
              "estimated_price": number,
              "carbonSaved": number,
              "review": {
                "specs": ["3 key specs"],
                "faults": ["specific flaws"],
                "grading_explanation": "summary"
              }
            }`
          }
        ],
      },
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });

    const result = JSON.parse(response.text || '{}');
    if (!result.item_name) throw new Error("Identification failed.");
    return result as VideoInspectionResult;
  } catch (e: any) {
    console.error("Audit Error:", e);
    throw new Error("Audit failed. Try better lighting.");
  }
};

/**
 * General Image Analysis for students (textbooks, circuits, components).
 * Uses gemini-3-pro-preview as per feature request.
 */
export const analyzeStudentImage = async (base64Image: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
        { text: "Analyze this image for an engineering student. If it's a textbook, explain the visible concept. If it's a circuit, identify components. If it's a tool, explain its use at BVDUCOEP." }
      ]
    },
    config: { thinkingConfig: { thinkingBudget: 2000 } }
  });
  return response.text || "Unable to analyze image.";
};

/**
 * AI Market Intelligence using Google Search Grounding.
 * Uses gemini-3-flash-preview with googleSearch tool.
 */
export const researchMarketPrice = async (itemName: string): Promise<GroundedResponse> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Find the current real-world market price in India for "${itemName}". Compare it to standard student second-hand prices. provide a verdict on whether it's a good deal for a student.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.filter(chunk => chunk.web)
    .map(chunk => ({
      title: chunk.web?.title || 'Source',
      uri: chunk.web?.uri || ''
    })) || [];

  return {
    text: response.text || "No market data found.",
    sources
  };
};

/**
 * Support Assistant with Search Grounding for accurate University info.
 */
export const getSupportResponse = async (query: string): Promise<GroundedResponse> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Support query for UniShare BVDUCOEP Hub: ${query}. Use search to provide accurate info about Bharati Vidyapeeth University Pune schedules, exam rules, or general engineering student FAQs.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.filter(chunk => chunk.web)
    .map(chunk => ({
      title: chunk.web?.title || 'Source',
      uri: chunk.web?.uri || ''
    })) || [];

  return {
    text: response.text || "I am currently unable to find an answer.",
    sources
  };
};

export const summarizeNote = async (title: string, dept: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Summarize key concepts for ${title} at ${dept} department.`
  });
  return response.text;
};

export const generateSmartSummaryFromPdf = async (base64Pdf: string, title: string) => {
  const ai = getAI();
  const base64Data = base64Pdf.includes(',') ? base64Pdf.split(',')[1] : base64Pdf;
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'application/pdf', data: base64Data } },
        { text: `3-bullet summary for ${title}.` }
      ]
    }
  });
  return response.text;
};

export const getHandoverZones = async (lat: number, lng: number) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `List handover spots near BVDUCOEP campus.`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: { latitude: lat, longitude: lng }
        }
      }
    }
  });
  return {
    text: response.text,
    grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const getSafeHandoverLocation = async (spotName: string, lat: number, lng: number) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Locate the "${spotName}" at Bharati Vidyapeeth Deemed University College of Engineering (BVDUCOEP), Pune. Confirm if it is a safe public zone for student trade.`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: { latitude: lat, longitude: lng }
        }
      }
    }
  });
  return {
    text: response.text,
    grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const compareMarketplaceItems = async (item1: MarketplaceItem, item2: MarketplaceItem) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Compare ${item1.title} and ${item2.title} for a student buyer.`
  });
  return response.text;
};

export const explainJWTClaims = async (payload: any) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Explain the following JWT payload claims in a technical but easy-to-understand way for a student engineer: ${JSON.stringify(payload)}`
  });
  return response.text;
};
