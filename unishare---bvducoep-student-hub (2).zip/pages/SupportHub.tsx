
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { getSupportResponse, GroundedResponse } from '../services/geminiService';

const SupportHub: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [query, setQuery] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'bot'; text: string; sources?: {title: string, uri: string}[] }[]>([]);
  const [botLoading, setBotLoading] = useState(false);
  const [userName, setUserName] = useState('Student');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (userStr) setUserName(JSON.parse(userStr).name);
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [chatHistory, botLoading]);

  const handleSupportQuery = async (e?: React.FormEvent, manualQuery?: string) => {
    if (e) e.preventDefault();
    const activeQuery = manualQuery || query;
    if (!activeQuery.trim() || botLoading) return;

    setChatHistory(prev => [...prev, { role: 'user', text: activeQuery }]);
    setQuery('');
    setBotLoading(true);

    try {
      const grounded: GroundedResponse = await getSupportResponse(activeQuery);
      setChatHistory(prev => [...prev, { role: 'bot', text: grounded.text, sources: grounded.sources }]);
    } catch (err) {
      setChatHistory(prev => [...prev, { role: 'bot', text: 'Error contacting support.' }]);
    } finally { setBotLoading(false); }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] animate-in slide-in-from-bottom-10 duration-500 rounded-[2.5rem] overflow-hidden bg-white/40 backdrop-blur-md border border-white/60 shadow-2xl mt-4">
      <header className="flex items-center justify-between px-6 py-5 bg-white/90 backdrop-blur-xl border-b border-white/40 shadow-sm shrink-0">
        <div className="flex items-center">
          <button onClick={() => navigate(-1)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-black/5 text-slate-700 active:scale-90"><i className="fas fa-arrow-left"></i></button>
          <div className="ml-3">
            <h2 className="text-sm font-black text-slate-900 uppercase tracking-widest">Grounded Support</h2>
            <div className="flex items-center gap-1.5 mt-1"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span><p className="text-[8px] text-blue-600 font-black uppercase">Live Search Enabled</p></div>
          </div>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
        <div className="bg-white/95 backdrop-blur-sm p-5 rounded-3xl rounded-tl-none border border-white/60 max-w-[85%] text-[11px] font-semibold text-slate-700 shadow-sm">
          <p className="mb-2">Hello, {userName}! I'm now powered by Google Search for accurate University info. 👋</p>
          <p className="italic text-slate-500 font-medium text-[9px]">Ask about exam dates, campus news, or student tools.</p>
        </div>

        {chatHistory.map((chat, i) => (
          <div key={i} className={`flex ${chat.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
            <div className={`p-5 rounded-[2rem] max-w-[85%] text-[11px] font-bold border ${chat.role === 'user' ? 'bg-blue-600 text-white border-blue-700 rounded-tr-none' : 'bg-white/95 text-slate-800 border-white/60 rounded-tl-none shadow-md'}`}>
              {chat.text}
              {chat.sources && chat.sources.length > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                  <span className="text-[8px] font-black uppercase text-slate-400 block tracking-widest">Sources</span>
                  {chat.sources.map((src, idx) => (
                    <a key={idx} href={src.uri} target="_blank" rel="noopener noreferrer" className="block text-[9px] text-blue-500 hover:underline truncate">
                      <i className="fas fa-link mr-1"></i> {src.title}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {botLoading && <div className="flex justify-start"><div className="bg-white/95 p-5 rounded-[2rem] rounded-tl-none border border-white/60 shadow-md animate-pulse">Searching Google...</div></div>}
      </div>

      <div className="p-5 bg-white/60 backdrop-blur-md border-t border-white/40 shrink-0">
        <form onSubmit={handleSupportQuery} className="bg-white rounded-[2rem] p-2 flex gap-2 shadow-2xl border border-slate-100">
          <input type="text" placeholder="Type your grounded query..." className="flex-1 bg-transparent border-none px-6 text-xs font-bold outline-none text-slate-800" value={query} onChange={(e) => setQuery(e.target.value)} />
          <button type="submit" disabled={!query.trim() || botLoading} className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg active:scale-90 disabled:bg-slate-200"><i className="fas fa-paper-plane text-xs"></i></button>
        </form>
      </div>
    </div>
  );
};

export default SupportHub;
