
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage, Language } from '../contexts/LanguageContext';
import Logo from '../components/Logo';
import { firestoreService } from '../services/firestoreService';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const { lang, setLang, t } = useLanguage();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');
    
    // Simulate Auth network delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const lowercaseEmail = email.toLowerCase().trim();

    // Strict University Domain Check
    if (lowercaseEmail.endsWith('@bvuniversity.edu.in')) {
      const generatedUid = btoa(lowercaseEmail).replace(/=/g, '');
      
      let user = await firestoreService.getUserByUid(generatedUid);
      const isNewUser = !user || !user.name;

      if (!user) {
        user = { 
          uid: generatedUid,
          email: lowercaseEmail, 
          name: '', 
          isLoggedIn: true,
          karma: 100,
          totalCarbonSaved: 0,
          isVerified: true,
          avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${generatedUid}`
        };
      }

      const token = firestoreService.generateSimulatedJWT(user);
      const authenticatedUser = { ...user, isLoggedIn: true, token };

      localStorage.setItem('user', JSON.stringify(authenticatedUser));
      onLogin(authenticatedUser);
      
      if (isNewUser) {
        navigate('/profile', { state: { setupMode: true } });
      } else {
        navigate('/');
      }
    } else {
      setError("Exclusive to @bvuniversity.edu.in emails only.");
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-900 overflow-hidden relative">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 w-64 h-64 bg-blue-500 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-10 right-10 w-64 h-64 bg-emerald-500 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-md bg-white rounded-[2.5rem] p-10 shadow-2xl relative z-10 animate-in zoom-in-95 duration-500">
        <div className="absolute top-6 right-8">
          <select 
            value={lang}
            onChange={(e) => setLang(e.target.value as Language)}
            className="bg-slate-50 border border-slate-100 text-[10px] font-black uppercase tracking-widest text-slate-500 py-2 pl-4 pr-8 rounded-xl outline-none"
          >
            <option value="en">EN</option>
            <option value="hi">HI</option>
            <option value="mr">MR</option>
          </select>
        </div>

        <div className="text-center mb-10">
          <div className="inline-block bg-blue-50 p-6 rounded-[2.5rem] mb-6 shadow-inner ring-4 ring-white">
            <Logo size={80} />
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">UniShare</h2>
          <p className="text-slate-400 text-[10px] uppercase font-black tracking-widest mt-2">BVDUCOEP Hub</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2 px-1">
              {t('loginEmail')}
            </label>
            <input 
              type="email" 
              required
              placeholder="student@bvuniversity.edu.in"
              className="w-full px-6 py-4 rounded-2xl border border-slate-200 bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-medium text-slate-800"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isSubmitting}
            />
            {error && (
              <p className="text-rose-500 text-[10px] mt-2 font-black uppercase flex items-center gap-1.5 animate-in slide-in-from-top-1">
                <i className="fas fa-exclamation-circle"></i> {error}
              </p>
            )}
          </div>

          <button 
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-slate-900 hover:bg-black text-white font-black py-5 rounded-2xl transition-all shadow-xl flex flex-col items-center justify-center gap-1 active:scale-95 disabled:opacity-50"
          >
            {isSubmitting ? (
              <i className="fas fa-circle-notch fa-spin"></i>
            ) : (
              <span className="text-xs uppercase tracking-[0.2em]">{t('enterApp')}</span>
            )}
          </button>
        </form>

        <div className="mt-10 p-5 bg-slate-50 rounded-2xl border border-slate-100 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
            Locked for BVDU Students Only.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
