
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { firestoreService } from '../services/firestoreService';
import { MarketplaceItem, StudyNote } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { getSafeHandoverLocation, researchMarketPrice, GroundedResponse } from '../services/geminiService';
import { BVDU_COORDINATES, CENTRAL_LIBRARY_COORDINATES } from '../constants';

const ItemDetail: React.FC = () => {
  const { type, id } = useParams<{ type: string; id: string }>();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [item, setItem] = useState<MarketplaceItem | StudyNote | null>(null);
  const [loading, setLoading] = useState(true);
  const [snackBar, setSnackBar] = useState({ show: false, msg: '' });
  const [isRequesting, setIsRequesting] = useState(false);
  
  const [activeTab, setActiveTab] = useState<'details' | 'safety' | 'market'>('details');
  const [mapData, setMapData] = useState<{ text: string, grounding: any[] } | null>(null);
  const [mapLoading, setMapLoading] = useState(false);

  const [marketData, setMarketData] = useState<GroundedResponse | null>(null);
  const [marketLoading, setMarketLoading] = useState(false);

  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userEmail = user.email || 'guest';

  useEffect(() => {
    if (!id || !type) return;
    if (type === 'listing') {
      const all = firestoreService.getListings();
      setItem(all.find(i => i.id === id) || null);
    } else {
      const all = firestoreService.getNotes();
      setItem(all.find(n => n.id === id) || null);
    }
    setLoading(false);
  }, [id, type]);

  const loadSafetyMap = async () => {
    if (mapData || mapLoading) return;
    setMapLoading(true);
    try {
      const result = await getSafeHandoverLocation('Central Library', BVDU_COORDINATES.latitude, BVDU_COORDINATES.longitude);
      setMapData(result as any);
    } catch (e) {
      console.error(e);
    } finally {
      setMapLoading(false);
    }
  };

  const loadMarketData = async () => {
    if (!item || marketData || marketLoading) return;
    setMarketLoading(true);
    try {
      const result = await researchMarketPrice(item.title);
      setMarketData(result);
    } catch (e) {
      console.error(e);
    } finally {
      setMarketLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'safety') loadSafetyMap();
    if (activeTab === 'market') loadMarketData();
  }, [activeTab]);

  const showToast = (msg: string) => {
    setSnackBar({ show: true, msg });
    setTimeout(() => setSnackBar({ show: false, msg: '' }), 5000);
  };

  const handleAction = async () => {
    if (!item) return;
    setIsRequesting(true);
    await firestoreService.setTradeStatus(item.id, 'requested', userEmail);
    showToast('Trade request sent!');
    setTimeout(() => { setIsRequesting(false); navigate(-1); }, 2000);
  };

  if (loading || !item) return <div className="p-20 text-center">Loading...</div>;

  const isListing = type === 'listing';
  const listing = item as MarketplaceItem;
  const isOwner = isListing ? listing.ownerEmail === userEmail : (item as StudyNote).authorEmail === userEmail;
  const hasReview = isListing && listing.honestReview;

  return (
    <div className="animate-in fade-in duration-500 pb-32">
      <header className="flex items-center gap-4 mb-8">
        <button onClick={() => navigate(-1)} className="w-12 h-12 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-colors">
          <i className="fas fa-arrow-left"></i>
        </button>
        <div className="flex flex-col">
          <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase leading-none">{item.title}</h2>
          {isListing && (
            <span className="text-[9px] font-black text-blue-600 uppercase tracking-widest mt-1">
              Listed for {listing.listingType}
            </span>
          )}
        </div>
      </header>

      {/* Tabs */}
      <div className="flex bg-slate-100 p-1.5 rounded-[2rem] mb-8 overflow-x-auto scrollbar-hide max-w-full border border-slate-200 shadow-inner">
        <button 
          onClick={() => setActiveTab('details')}
          className={`shrink-0 px-6 py-3 rounded-[1.5rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'details' ? 'bg-white text-blue-600 shadow-xl scale-105' : 'text-slate-500'}`}
        >
          <i className="fas fa-circle-info mr-2"></i> Details
        </button>
        <button 
          onClick={() => setActiveTab('safety')}
          className={`shrink-0 px-6 py-3 rounded-[1.5rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'safety' ? 'bg-white text-emerald-600 shadow-xl scale-105' : 'text-slate-500'}`}
        >
          <i className="fas fa-map-location-dot mr-2"></i> Campus
        </button>
        <button 
          onClick={() => setActiveTab('market')}
          className={`shrink-0 px-6 py-3 rounded-[1.5rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'market' ? 'bg-white text-indigo-600 shadow-xl scale-105' : 'text-slate-500'}`}
        >
          <i className="fas fa-chart-line mr-2"></i> Market AI
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          {activeTab === 'details' ? (
            <>
              <div className="aspect-square rounded-[3rem] overflow-hidden bg-white shadow-xl border border-slate-100 relative flex items-center justify-center group">
                {isListing && listing.imageUrl ? (
                  <img src={listing.imageUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" />
                ) : (
                  <div className={`w-full h-full flex flex-col items-center justify-center gap-4 ${isListing ? 'bg-slate-50 text-slate-200' : 'bg-rose-50 text-rose-500'}`}>
                    <i className={`fas ${isListing ? 'fa-box-open' : 'fa-file-pdf'} text-9xl`}></i>
                    <span className="text-[10px] font-black uppercase tracking-[0.4em] opacity-40">Verified Asset</span>
                  </div>
                )}
              </div>
              
              <div className="bg-emerald-50 p-6 rounded-[2.5rem] border border-emerald-100 flex items-center gap-4">
                 <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-inner">
                    <i className="fas fa-leaf text-xl"></i>
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-emerald-800 uppercase tracking-widest">Legacy Impact</p>
                    <p className="text-xs font-bold text-emerald-600">{isListing ? listing.carbonSaved : '0.2'}kg Carbon Saved</p>
                 </div>
              </div>
            </>
          ) : activeTab === 'safety' ? (
            <div className="space-y-6 animate-in zoom-in-95 duration-500">
               <div className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-2xl relative overflow-hidden min-h-[400px]">
                  <div className="relative z-10 flex flex-col h-full">
                    <div className="flex items-center justify-between mb-8">
                      <div className="flex flex-col gap-1">
                        <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight">Safety Geofence</h4>
                        <span className="text-[8px] font-black text-emerald-600 uppercase tracking-[0.2em]">Verified Hub</span>
                      </div>
                      <i className="fas fa-shield-halved text-emerald-500 text-xl"></i>
                    </div>
                    <div className="flex-1 bg-slate-100 rounded-3xl mb-6 relative overflow-hidden border border-slate-200">
                       <div className="absolute inset-0 flex items-center justify-center">
                          <i className="fas fa-location-dot text-emerald-600 text-3xl animate-bounce"></i>
                       </div>
                    </div>
                    {mapLoading ? <div className="animate-pulse text-[10px] uppercase font-black text-slate-400">Loading Map...</div> : mapData && <p className="text-xs text-slate-500 italic">{mapData.text}</p>}
                  </div>
               </div>
            </div>
          ) : (
            <div className="space-y-6 animate-in zoom-in-95 duration-500">
               <div className="bg-indigo-900 rounded-[3rem] p-8 text-white shadow-2xl relative overflow-hidden min-h-[400px]">
                  <h4 className="text-lg font-black uppercase tracking-tight mb-6">Market Intelligence</h4>
                  {marketLoading ? (
                    <div className="flex flex-col items-center justify-center h-48 gap-4">
                       <div className="w-10 h-10 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                       <p className="text-[9px] font-black uppercase tracking-widest opacity-60">Scouring E-commerce sites...</p>
                    </div>
                  ) : marketData ? (
                    <div className="space-y-6">
                       <div className="p-4 bg-white/10 rounded-2xl border border-white/10 text-[11px] font-medium leading-relaxed italic">
                         {marketData.text}
                       </div>
                       <div className="space-y-3">
                         <span className="text-[8px] font-black uppercase tracking-widest text-indigo-300">Grounding Sources</span>
                         {marketData.sources.map((src, i) => (
                           <a key={i} href={src.uri} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 bg-white/5 rounded-xl text-[10px] hover:bg-white/10 transition-all">
                              <span className="truncate max-w-[180px]">{src.title}</span>
                              <i className="fas fa-external-link-alt text-[8px] opacity-40"></i>
                           </a>
                         ))}
                       </div>
                    </div>
                  ) : <p className="text-xs opacity-60 italic">Could not load market data.</p>}
                  <i className="fas fa-globe absolute -bottom-10 -right-10 text-white/5 text-[180px] rotate-12"></i>
               </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-2xl">
             <div className="flex justify-between items-start mb-6">
                <h3 className="text-4xl font-black text-slate-900 tracking-tighter">
                  {listing.listingType === 'Free' ? 'FREE' : `₹${listing.price}`}
                </h3>
             </div>
             <p className="text-slate-500 text-sm leading-relaxed mb-8">{listing.description}</p>
             {!isOwner && (
               <button 
                 onClick={handleAction} 
                 disabled={isRequesting}
                 className="w-full py-5 bg-slate-900 hover:bg-black text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[10px] transition-all active:scale-95 shadow-xl disabled:opacity-50"
               >
                 {isRequesting ? <i className="fas fa-circle-notch fa-spin"></i> : `Request ${listing.listingType}`}
               </button>
             )}
          </div>

          {hasReview && activeTab === 'details' && (
            <div className="bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl space-y-6 relative overflow-hidden">
               <h4 className="text-lg font-black text-white uppercase tracking-tight">Technical Audit</h4>
               <div className="bg-white/5 backdrop-blur-md p-6 rounded-2xl border border-white/10 mb-4">
                  <div className="space-y-2">
                     {listing.honestReview?.faults.length ? listing.honestReview.faults.map((f, i) => (
                       <div key={i} className="flex items-center gap-3 text-rose-400 text-xs font-bold">
                         <i className="fas fa-circle-exclamation text-[10px]"></i> {f}
                       </div>
                     )) : <div className="text-emerald-400 text-xs font-bold"><i className="fas fa-check-circle"></i> Perfect condition.</div>}
                  </div>
               </div>
               <p className="text-[11px] text-slate-400 italic leading-relaxed">
                 "Gemini 3 Pro Audit: {listing.honestReview?.grading_explanation}"
               </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ItemDetail;
