
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { User, Department, MarketplaceItem } from '../types';
import { firestoreService } from '../services/firestoreService';

interface AssetDisplay {
  id: string;
  title: string;
  price?: number;
  imageUrl?: string;
  type: 'item' | 'note';
  listingType?: string;
  condition?: string;
}

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [userData, setUserData] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(location.state?.setupMode || false);
  const [myAssets, setMyAssets] = useState<AssetDisplay[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  
  const [form, setForm] = useState({
    name: '',
    department: 'Computer' as Department,
    classYear: 'FE' as 'FE' | 'SE' | 'TE' | 'BE',
    rollNumber: '',
    avatarUrl: ''
  });

  const departments: Department[] = ['Computer', 'IT', 'E&TC', 'Mechanical', 'Civil', 'Chemical', 'Robotics', 'AI&DS', '1st Year (General)'];
  const years: ('FE' | 'SE' | 'TE' | 'BE')[] = ['FE', 'SE', 'TE', 'BE'];

  useEffect(() => {
    const session = JSON.parse(localStorage.getItem('user') || 'null');
    if (!session) {
      navigate('/login');
      return;
    }

    const unsubscribeUser = firestoreService.subscribeToUser(session.uid, (user) => {
      if (user) {
        setUserData(user);
        setForm({
          name: user.name || '',
          department: user.department || 'Computer',
          classYear: user.classYear || 'FE',
          rollNumber: user.rollNumber || '',
          avatarUrl: user.avatarUrl || ''
        });

        if (!user.name) {
          setIsEditing(true);
        }
      }
      setLoading(false);
    });

    const unsubscribeListings = firestoreService.subscribeToListings((all) => {
      const filteredItems: AssetDisplay[] = all
        .filter(item => item.ownerEmail === session.email)
        .map(i => ({
          id: i.id,
          title: i.title,
          price: i.price,
          imageUrl: i.imageUrl,
          type: 'item',
          listingType: i.listingType,
          condition: i.condition
        }));
      setMyAssets(filteredItems);
    });

    return () => {
      unsubscribeUser();
      unsubscribeListings();
    };
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    window.location.href = '#/login';
    window.location.reload();
  };

  const handleAvatarClick = () => {
    if (isEditing) {
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setForm(prev => ({ ...prev, avatarUrl: base64 }));
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!userData) return;
    if (!form.name.trim() || !form.rollNumber.trim()) {
      alert("Name and Roll Number are mandatory to link your identity.");
      return;
    }
    const updatedUser: User = { ...userData, ...form };
    await firestoreService.saveUser(updatedUser);
    setIsEditing(false);
    if (location.state?.setupMode) {
      navigate('/');
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Linking Identity...</p>
    </div>
  );

  if (!userData) return null;

  const karma = userData.karma ?? 100;
  const rankInfo = karma >= 150 ? { label: 'Legendary', icon: 'fa-crown', color: 'text-amber-500' } : { label: 'Student', icon: 'fa-user-graduate', color: 'text-blue-500' };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12 animate-in slide-in-from-bottom-4 duration-500">
      <div className="lg:col-span-2 space-y-10">
        <div className="bg-white/80 backdrop-blur-2xl rounded-[2.5rem] p-8 border border-white/60 shadow-2xl relative overflow-hidden">
          {location.state?.setupMode && (
            <div className="mb-8 p-5 bg-blue-600 text-white rounded-3xl flex items-center gap-4 animate-bounce shadow-xl shadow-blue-200">
               <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
                 <i className="fas fa-id-card"></i>
               </div>
               <div>
                  <h4 className="text-[10px] font-black uppercase tracking-widest">Setup Phase</h4>
                  <p className="text-xs font-bold opacity-80">Link your Student ID and add a profile picture to begin trading.</p>
               </div>
            </div>
          )}

          <div className="flex flex-col items-center text-center relative z-10">
            <div className="relative mb-6 group">
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleFileChange}
              />
              <div 
                onClick={handleAvatarClick}
                className={`w-32 h-32 rounded-[2.5rem] bg-slate-100 overflow-hidden flex items-center justify-center border-4 border-white shadow-2xl transition-all ${isEditing ? 'cursor-pointer hover:ring-4 hover:ring-blue-500/20' : ''}`}
              >
                {uploading ? (
                  <i className="fas fa-circle-notch fa-spin text-blue-500 text-3xl"></i>
                ) : form.avatarUrl ? (
                  <img src={form.avatarUrl} className="w-full h-full object-cover" alt="Profile" />
                ) : (
                  <i className="fas fa-user-graduate text-5xl text-slate-300"></i>
                )}
                
                {isEditing && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-[2.5rem]">
                    <i className="fas fa-camera text-white text-2xl"></i>
                  </div>
                )}
              </div>
              <div className={`absolute -bottom-2 -right-2 w-10 h-10 rounded-xl bg-white ${rankInfo.color} border-2 border-slate-50 flex items-center justify-center shadow-lg`}>
                <i className={`fas ${rankInfo.icon}`}></i>
              </div>
            </div>

            {!isEditing ? (
              <div className="space-y-4 w-full">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-center gap-3">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">{userData.name}</h2>
                    <div className="bg-blue-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-[10px] shadow-lg border border-white">
                      <i className="fas fa-check"></i>
                    </div>
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{userData.email}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <div className="bg-white/60 backdrop-blur-md p-4 rounded-2xl text-center border border-slate-100 shadow-sm">
                    <span className="block text-[8px] font-black text-slate-400 uppercase mb-1 tracking-widest">Branch</span>
                    <span className="text-xs font-black text-slate-700">{userData.department}</span>
                  </div>
                  <div className="bg-white/60 backdrop-blur-md p-4 rounded-2xl text-center border border-slate-100 shadow-sm">
                    <span className="block text-[8px] font-black text-slate-400 uppercase mb-1 tracking-widest">Student ID</span>
                    <span className="text-xs font-black text-slate-700">{userData.rollNumber}</span>
                  </div>
                </div>

                <button onClick={() => setIsEditing(true)} className="mt-4 px-8 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase shadow-xl active:scale-95 transition-all">Update Identity</button>
              </div>
            ) : (
              <div className="w-full space-y-4 text-left">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-400 px-1">Full Student Name (Mandatory)</label>
                  <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-white/60 p-4 rounded-xl font-bold border border-slate-100 outline-none focus:border-blue-500 transition-colors shadow-inner" placeholder="As per BVDU records" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-400 px-1">Branch</label>
                    <select value={form.department} onChange={e => setForm({...form, department: e.target.value as any})} className="w-full bg-white/60 p-4 rounded-xl font-bold border border-slate-100 shadow-inner">
                      {departments.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-400 px-1">Year</label>
                    <select value={form.classYear} onChange={e => setForm({...form, classYear: e.target.value as any})} className="w-full bg-white/60 p-4 rounded-xl font-bold border border-slate-100 shadow-inner">
                      {years.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black uppercase text-slate-400 px-1">BVDU Roll Number / ID (Mandatory)</label>
                   <input value={form.rollNumber} onChange={e => setForm({...form, rollNumber: e.target.value})} className="w-full bg-white/60 p-4 rounded-xl font-bold border border-slate-100 outline-none focus:border-blue-500 transition-colors shadow-inner" placeholder="e.g. 211040..." />
                </div>
                <div className="flex gap-3 pt-4">
                  {userData.name && (
                    <button onClick={() => setIsEditing(false)} className="flex-1 py-4 bg-white/80 rounded-2xl font-black uppercase text-[10px] hover:bg-slate-50 transition-colors shadow-sm">Cancel</button>
                  )}
                  <button onClick={handleSave} className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase text-[10px] shadow-lg shadow-blue-100 hover:bg-blue-700 transition-colors">Link Identity</button>
                </div>
              </div>
            )}
          </div>
        </div>

        {userData.name && (
          <div className="space-y-4">
            <h4 className="text-[10px] font-black uppercase text-slate-500 tracking-widest px-4">My Linked Listings</h4>
            <div className="space-y-3">
              {myAssets.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-[10px] font-bold uppercase tracking-widest bg-white/50 backdrop-blur-md rounded-3xl border border-dashed border-slate-200">No active assets.</div>
              ) : (
                myAssets.map(item => (
                  <div key={item.id} className="bg-white/90 backdrop-blur-md p-4 rounded-3xl border border-white/60 shadow-md flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-50 overflow-hidden flex items-center justify-center text-slate-300">
                      {item.imageUrl ? (
                        <img src={item.imageUrl} className="w-full h-full object-cover" alt="" />
                      ) : (
                        <i className="fas fa-box text-sm"></i>
                      )}
                    </div>
                    <div className="flex-1">
                      <h5 className="font-bold text-slate-900 text-xs uppercase">{item.title}</h5>
                      <span className="text-[8px] font-black text-blue-500 uppercase">{item.listingType}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      <div className="space-y-6">
        <h4 className="text-[10px] font-black uppercase text-slate-500 px-2 tracking-widest">Session</h4>
        <div className="bg-white/80 backdrop-blur-2xl rounded-[2.5rem] p-6 border border-white/60 shadow-2xl space-y-2">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-between p-4 bg-rose-50 text-rose-600 rounded-2xl border border-rose-100 hover:bg-rose-500 hover:text-white transition-all group"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-sm">
                <i className="fas fa-sign-out-alt"></i>
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest">Logout Session</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
