
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Department, Category, MarketplaceItem, ListingType, HonestReview, QualityGrade } from '../types';
import { firestoreService } from '../services/firestoreService';

const AddListing: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    listingType: 'Sell' as ListingType,
    rentDuration: '1 Week',
    interestRate: '0',
    securityDeposit: '',
    department: '1st Year (General)' as Department,
    category: Category.GENERAL_ESSENTIALS as Category,
    carbonSaved: 0,
    imageUrl: ''
  });

  const [honestReview, setHonestReview] = useState<HonestReview | null>(null);
  const [qualityGrade, setQualityGrade] = useState<QualityGrade>('B');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [snackBar, setSnackBar] = useState<{ show: boolean; msg: string }>({ show: false, msg: '' });

  const departments: Department[] = ['1st Year (General)', 'Computer', 'IT', 'Mechanical', 'Civil', 'E&TC', 'Chemical', 'Robotics', 'AI&DS'];
  const categories = Object.values(Category);
  const rentDurations = ['3 Days', '1 Week', '2 Weeks', '1 Month', 'Full Semester'];

  useEffect(() => {
    if (location.state?.prefill) {
      const { prefill } = location.state;
      setFormData(prev => ({
        ...prev,
        name: prefill.item_name || '',
        category: prefill.category || Category.GENERAL_ESSENTIALS,
        description: prefill.description || `Verified ${prefill.item_name} for engineering students.`,
        price: prefill.estimated_price?.toString() || '',
        carbonSaved: prefill.carbonSaved || 0.5,
        imageUrl: prefill.previewUrl || ''
      }));
      setHonestReview(prefill.honestReview || null);
      setQualityGrade(prefill.quality_grade || 'B');
    } else {
        navigate('/scan');
    }
  }, [location.state, navigate]);

  const showToast = (msg: string) => {
    setSnackBar({ show: true, msg });
    setTimeout(() => setSnackBar({ show: false, msg: '' }), 4000);
  };

  const getGradeMeta = (grade: QualityGrade) => {
    switch(grade) {
      case 'A': return { label: 'Pristine / Mint', color: 'bg-emerald-500', text: 'text-emerald-500', bg: 'bg-emerald-50', icon: 'fa-certificate', desc: 'Technical inspection found zero defects.' };
      case 'C': return { label: 'Functional / Damaged', color: 'bg-rose-500', text: 'text-rose-500', bg: 'bg-rose-50', icon: 'fa-triangle-exclamation', desc: 'Minor defects detected but usable.' };
      default: return { label: 'Reliable / Used', color: 'bg-blue-500', text: 'text-blue-500', bg: 'bg-blue-50', icon: 'fa-check-double', desc: 'Verified for departmental lab standards.' };
    }
  };

  const gradeMeta = getGradeMeta(qualityGrade);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.imageUrl) {
      showToast("Scan image is required.");
      return;
    }
    
    setIsSubmitting(true);
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      
      const newListing: MarketplaceItem = {
        id: `listing-${Date.now()}`,
        title: formData.name,
        description: formData.description,
        listingType: formData.listingType,
        price: formData.listingType === 'Free' ? 0 : Number(formData.price),
        rentDuration: formData.listingType === 'Rent' ? formData.rentDuration : undefined,
        interestRate: formData.listingType === 'Rent' ? Number(formData.interestRate) : undefined,
        securityDeposit: (formData.listingType === 'Rent' || formData.listingType === 'Free') ? Number(formData.securityDeposit) : undefined,
        category: formData.category,
        department: formData.department,
        owner: user.name || 'Student',
        ownerEmail: user.email,
        ownerKarma: user.karma || 100,
        imageUrl: formData.imageUrl,
        honestReview: honestReview || undefined,
        condition: `${gradeMeta.label} (AI Verified)`, 
        createdAt: 'Just now',
        carbonSaved: formData.carbonSaved || 0.5
      };

      await firestoreService.createListing(newListing);
      alert(t('listingSuccess'));
      navigate('/');
    } catch (error) {
      console.error("Failed to create listing:", error);
      showToast("Error saving listing.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-6 duration-700 pb-24 relative">
      <div className="flex items-center gap-5">
        <button onClick={() => navigate(-1)} className="w-12 h-12 rounded-2xl bg-white border border-slate-100 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-colors shadow-sm active:scale-90">
          <i className="fas fa-arrow-left"></i>
        </button>
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase leading-none">AI Audit Certificate</h2>
          <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mt-1.5">Technical Assessment Complete</p>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl overflow-hidden">
        {/* Quality Header */}
        <div className="bg-slate-900 p-8 text-white relative">
           <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-6">
                 <div className={`w-24 h-24 rounded-[2rem] ${gradeMeta.color} flex flex-col items-center justify-center shadow-2xl ring-4 ring-white/10 transition-colors duration-500`}>
                   <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Grade</span>
                   <span className="text-4xl font-black">{qualityGrade}</span>
                 </div>
                 <div>
                    <h3 className="text-xl font-black uppercase tracking-tight transition-colors">{gradeMeta.label}</h3>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{gradeMeta.desc}</p>
                 </div>
              </div>
           </div>
           <i className="fas fa-shield-halved absolute -bottom-10 -right-10 text-white/5 text-[180px] rotate-12"></i>
        </div>

        <div className="p-8 space-y-10">
          {/* Audit Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
               <div className="relative aspect-video rounded-3xl overflow-hidden bg-slate-100 border-4 border-slate-50 shadow-inner group">
                  {formData.imageUrl && <img src={formData.imageUrl} className="w-full h-full object-cover" alt="Audit Proof" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                     <span className="bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest border border-white/20">
                        Scan ID: #{Math.random().toString(36).substr(2, 6).toUpperCase()}
                     </span>
                     <span className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg">
                        AI Certified
                     </span>
                  </div>
               </div>

               {/* Inspection Findings */}
               <div className="bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100 space-y-6">
                  <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.2em] flex items-center gap-2">
                    <i className="fas fa-microscope text-blue-600"></i> Inspection Findings
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div className="bg-white p-4 rounded-2xl border border-slate-100">
                        <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-3">Identified Specs</span>
                        <div className="space-y-2">
                           {honestReview?.specs.map((s, i) => (
                             <div key={i} className="text-[10px] font-bold text-slate-700 flex items-center gap-2">
                               <i className="fas fa-check text-emerald-500"></i> {s}
                             </div>
                           ))}
                        </div>
                     </div>
                     <div className={`bg-white p-4 rounded-2xl border ${honestReview?.faults.length ? 'border-rose-100' : 'border-slate-100'}`}>
                        <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-3">Defects Detected</span>
                        <div className="space-y-2">
                           {honestReview?.faults.length ? honestReview.faults.map((f, i) => (
                             <div key={i} className="text-[10px] font-bold text-rose-600 flex items-center gap-2">
                               <i className="fas fa-triangle-exclamation"></i> {f}
                             </div>
                           )) : (
                             <div className="text-[10px] font-bold text-emerald-600 flex items-center gap-2">
                               <i className="fas fa-check-circle"></i> No bent pins or burnt components
                             </div>
                           )}
                        </div>
                     </div>
                  </div>

                  <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                    <p className="text-[11px] font-medium text-slate-600 leading-relaxed italic">
                      "Gemini Audit: {honestReview?.grading_explanation}"
                    </p>
                  </div>
               </div>
            </div>

            <div className="space-y-6">
              <div className="bg-emerald-50/50 p-6 rounded-[2.5rem] border border-emerald-100 text-center space-y-3">
                 <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-emerald-600 mx-auto shadow-sm">
                   <i className="fas fa-leaf text-2xl"></i>
                 </div>
                 <h4 className="text-[10px] font-black text-emerald-800 uppercase tracking-widest">Sustainability</h4>
                 <p className="text-xl font-black text-emerald-900">{formData.carbonSaved}kg</p>
                 <p className="text-[8px] font-bold text-emerald-600 uppercase">CO2 Emissions Saved</p>
              </div>

              <div className="bg-slate-50 p-6 rounded-[2.5rem] border border-slate-100">
                <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-4 text-center">Trade Options</span>
                <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-inner">
                  {(['Sell', 'Rent', 'Free'] as ListingType[]).map((type) => (
                    <button 
                      key={type} 
                      type="button" 
                      onClick={() => setFormData(prev => ({ ...prev, listingType: type }))} 
                      className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${formData.listingType === type ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:text-slate-900'}`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 text-center">Base Student Price (₹)</label>
                <input 
                  type="number" 
                  name="price" 
                  required 
                  className="w-full px-6 py-5 rounded-[2rem] border-2 border-slate-200 bg-white outline-none font-black text-slate-900 text-xl text-center focus:border-blue-500 transition-all shadow-xl" 
                  value={formData.price} 
                  onChange={handleChange} 
                />
                <p className="text-[8px] font-bold text-blue-600 uppercase text-center mt-1">Suggested by AI Auditor</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 pt-6 border-t border-slate-100">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 px-1">Display Name</label>
                <input name="name" required className="w-full px-6 py-4 rounded-2xl border border-slate-200 bg-white outline-none font-bold text-slate-800 transition-all focus:ring-4 focus:ring-blue-500/10 shadow-sm" value={formData.name} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 px-1">University Department</label>
                <select name="department" className="w-full px-6 py-4 rounded-2xl border border-slate-200 bg-white font-bold text-slate-800 outline-none" value={formData.department} onChange={handleChange}>
                  {departments.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 px-1">Brief Description</label>
              <textarea name="description" required className="w-full px-6 py-4 rounded-2xl border border-slate-200 bg-white outline-none font-medium text-slate-800 transition-all focus:ring-4 focus:ring-blue-500/10 shadow-sm h-32" value={formData.description} onChange={handleChange} />
            </div>

            <button type="submit" disabled={isSubmitting} className="w-full bg-slate-900 hover:bg-black text-white font-black py-6 rounded-[2.5rem] transition-all shadow-2xl flex items-center justify-center gap-4 active:scale-95 group">
              {isSubmitting ? <i className="fas fa-circle-notch fa-spin"></i> : (
                <>
                  <i className="fas fa-check-circle text-blue-500 group-hover:scale-125 transition-transform"></i> 
                  <span className="text-xs uppercase tracking-[0.2em]">Submit Verified Listing</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddListing;
