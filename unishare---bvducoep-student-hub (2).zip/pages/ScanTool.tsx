
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { analyzeTechnicalCondition, analyzeStudentImage, VideoInspectionResult } from '../services/geminiService';
import { useLanguage } from '../contexts/LanguageContext';

const ScanTool: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraLoading, setCameraLoading] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisMode, setAnalysisMode] = useState<'audit' | 'lens'>('audit');
  const [lensResult, setLensResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [capturedFrames, setCapturedFrames] = useState<string[]>([]);
  
  const framesRef = useRef<string[]>([]);
  const captureIntervalRef = useRef<number | null>(null);

  const startCamera = async () => {
    setCameraLoading(true);
    setError(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 } },
        audio: false 
      });
      setStream(s);
      setCameraLoading(false);
    } catch (err) {
      setError("Unable to access camera.");
      setCameraLoading(false);
    }
  };

  useEffect(() => {
    if (stream && videoRef.current && !isAnalyzing && !error) {
      videoRef.current.srcObject = stream;
    }
  }, [stream, isAnalyzing, error]);

  useEffect(() => {
    startCamera();
    return () => {
      stream?.getTracks().forEach(t => t.stop());
      if (captureIntervalRef.current) window.clearInterval(captureIntervalRef.current);
    };
  }, []);

  const captureFrame = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx || video.videoHeight === 0) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
    framesRef.current.push(base64);
    setCapturedFrames([...framesRef.current]);
    if (framesRef.current.length >= 12) stopRecording();
  };

  const handleAudit = async () => {
    if (!videoRef.current || !canvasRef.current || isAnalyzing) return;
    setIsAnalyzing(true);
    setLensResult(null);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];
    
    try {
      const result = await analyzeTechnicalCondition([base64]);
      navigate('/add-listing', { 
        state: { prefill: { ...result, previewUrl: `data:image/jpeg;base64,${base64}`, honestReview: result.review, name: result.item_name } }
      });
    } catch (err: any) {
      setError(err.message);
      setIsAnalyzing(false);
    }
  };

  const handleGeneralLens = async () => {
    if (!videoRef.current || !canvasRef.current || isAnalyzing) return;
    setIsAnalyzing(true);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];
    
    try {
      const result = await analyzeStudentImage(base64);
      setLensResult(result);
      setIsAnalyzing(false);
    } catch (err: any) {
      setError("AI Lens failed to recognize context.");
      setIsAnalyzing(false);
    }
  };

  const startRecording = () => {
    setIsRecording(true);
    framesRef.current = [];
    captureIntervalRef.current = window.setInterval(captureFrame, 1000);
  };

  const stopRecording = () => {
    if (captureIntervalRef.current) window.clearInterval(captureIntervalRef.current);
    setIsRecording(false);
    if (framesRef.current.length >= 2) processScan();
  };

  const processScan = async () => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeTechnicalCondition(framesRef.current);
      navigate('/add-listing', { state: { prefill: { ...result, previewUrl: `data:image/jpeg;base64,${framesRef.current[0]}`, honestReview: result.review, name: result.item_name } } });
    } catch (err: any) { setError("Full scan failed."); }
    finally { setIsAnalyzing(false); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 flex flex-col overflow-hidden">
      <canvas ref={canvasRef} className="hidden" />
      <header className="p-6 flex items-center justify-between text-white bg-slate-900/80 backdrop-blur-md shrink-0">
        <button onClick={() => navigate(-1)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/10 transition-all"><i className="fas fa-times"></i></button>
        <div className="flex bg-white/10 p-1 rounded-2xl border border-white/10">
           <button onClick={() => { setAnalysisMode('audit'); setLensResult(null); }} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest ${analysisMode === 'audit' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>Tech Audit</button>
           <button onClick={() => { setAnalysisMode('lens'); setLensResult(null); }} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest ${analysisMode === 'lens' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}>AI Lens</button>
        </div>
        <div className="w-10"></div>
      </header>

      <div className="flex-1 relative bg-black">
        {isAnalyzing ? (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 px-10 text-center">
             <div className="w-16 h-16 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mb-6"></div>
             <p className="text-white text-[10px] font-black uppercase tracking-widest animate-pulse">
                {analysisMode === 'audit' ? 'Performing Technical Inspection...' : 'Analyzing Engineering Context...'}
             </p>
          </div>
        ) : lensResult ? (
          <div className="absolute inset-0 z-50 bg-slate-900 p-8 flex flex-col">
             <h3 className="text-blue-400 text-[10px] font-black uppercase tracking-widest mb-4">Gemini Lens Result</h3>
             <div className="flex-1 overflow-y-auto text-slate-300 text-xs leading-relaxed italic border border-white/10 p-6 rounded-[2rem] bg-white/5 scrollbar-hide">
               {lensResult}
             </div>
             <button onClick={() => setLensResult(null)} className="mt-6 w-full py-4 bg-white/10 text-white rounded-2xl font-black uppercase text-[10px]">New Scan</button>
          </div>
        ) : (
          <>
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover opacity-60" />
            <div className="absolute bottom-12 left-0 right-0 z-40 px-10 flex flex-col gap-4">
               {analysisMode === 'audit' ? (
                 <div className="flex gap-4">
                    <button onClick={handleAudit} className="flex-1 py-4 bg-white/10 text-white border border-white/20 rounded-2xl font-black uppercase text-[9px]">Single Shot Audit</button>
                    <button onClick={isRecording ? stopRecording : startRecording} className={`flex-[1.5] py-5 rounded-2xl font-black uppercase text-[10px] ${isRecording ? 'bg-rose-500' : 'bg-blue-600'} text-white`}>
                      {isRecording ? "Stop 360°" : "Full 360° Scan"}
                    </button>
                 </div>
               ) : (
                 <button onClick={handleGeneralLens} className="w-full py-6 bg-indigo-600 text-white rounded-3xl font-black uppercase tracking-[0.2em] text-xs shadow-2xl shadow-indigo-900/50">
                    <i className="fas fa-wand-magic-sparkles mr-3"></i> Analyze with Gemini 3 Pro
                 </button>
               )}
            </div>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
               <div className="w-72 h-72 border-2 border-dashed border-white/20 rounded-[4rem]"></div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ScanTool;
