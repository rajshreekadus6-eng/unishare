
import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Category, MarketplaceItem } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { firestoreService } from '../services/firestoreService';

const Marketplace: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [categoryFilter, setCategoryFilter] = useState<Category | 'All' | 'Wishlist'>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [wishlist, setWishlist] = useState<MarketplaceItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userEmail = user.email || 'guest';

  useEffect(() => {
    const unsubscribe = firestoreService.subscribeToListings((data) => {
      setItems(data);
      setWishlist(firestoreService.getWishlist(userEmail));
      setLoading(false);
    });
    return () => unsubscribe();
  }, [userEmail]);

  const categories = Object.values(Category);

  const filteredItems = useMemo(() => {
    let list = items;
    if (categoryFilter === 'Wishlist') {
      const wishlistIds = wishlist.map(i => i.id);
      list = items.filter(i => wishlistIds.includes(i.id));
    } else if (categoryFilter !== 'All') {
      list = items.filter(i => i.category === categoryFilter);
    }
    return list.filter(item => 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.department.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [items, categoryFilter, searchTerm, wishlist]);

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between px-1">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{t('tradeCenter')}</h2>
          <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mt-1">Sustainable Hub for BVDUCOEP</p>
        </div>
        <button onClick={() => navigate('/scan')} className="w-14 h-14 bg-slate-900 text-white rounded-[1.5rem] shadow-2xl flex items-center justify-center active:scale-95 transition-all group">
          <i className="fas fa-plus group-hover:rotate-90 transition-transform"></i>
        </button>
      </div>

      <div className="relative group">
        <input 
          type="text" 
          placeholder={t('searchPlaceholder')}
          className="w-full pl-14 pr-6 py-5 rounded-[2rem] bg-white border border-slate-100 outline-none shadow-sm font-bold text-slate-700 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <i className="fas fa-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-colors"></i>
      </div>

      {/* Categories Scroller */}
      <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide px-1">
        <button 
          onClick={() => setCategoryFilter('All')}
          className={`shrink-0 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${categoryFilter === 'All' ? 'bg-slate-900 text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-50'}`}
        >All</button>
        <button 
          onClick={() => setCategoryFilter('Wishlist')}
          className={`shrink-0 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${categoryFilter === 'Wishlist' ? 'bg-rose-500 text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-50'}`}
        >
          <i className="fas fa-heart mr-2"></i>Wishlist
        </button>
        {categories.map(cat => (
          <button 
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`shrink-0 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${categoryFilter === cat ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-50'}`}
          >{cat}</button>
        ))}
      </div>

      {loading ? (
        <div className="flex flex-col items-center py-20 gap-4">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Opening Market...</span>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="py-24 text-center space-y-6 bg-white/50 backdrop-blur-md rounded-[3rem] border border-dashed border-slate-200">
           <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-300">
             <i className="fas fa-box-open text-4xl"></i>
           </div>
           <div className="space-y-2 px-6">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">The marketplace is currently empty.</p>
             <p className="text-xs font-medium text-slate-400 max-w-xs mx-auto">Be the first to list your engineering gear and help your juniors at BVDUCOEP!</p>
           </div>
           <button 
             onClick={() => navigate('/scan')} 
             className="px-8 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all"
           >
             Create First Listing
           </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {filteredItems.map((item) => (
            <Link 
              key={item.id} 
              to={`/item/listing/${item.id}`}
              className="bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all flex flex-col group animate-in fade-in slide-in-from-bottom-2"
            >
              <div className="relative h-56 overflow-hidden bg-slate-50 flex items-center justify-center">
                {item.imageUrl ? (
                  <img src={item.imageUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={item.title} />
                ) : (
                  <div className="flex flex-col items-center gap-3 text-slate-200">
                    <i className="fas fa-box-open text-5xl"></i>
                    <span className="text-[8px] font-black uppercase tracking-[0.3em]">No Preview</span>
                  </div>
                )}
                <div className="absolute top-5 left-5">
                  <div className={`px-4 py-2 rounded-2xl text-[9px] font-black uppercase tracking-widest text-white shadow-2xl backdrop-blur-md border border-white/20 ${item.listingType === 'Sell' ? 'bg-blue-600/80' : 'bg-emerald-500/80'}`}>
                    {item.listingType}
                  </div>
                </div>
                <div className="absolute bottom-5 right-5">
                   <div className="bg-slate-900/80 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-[8px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-lg">
                      <i className="fas fa-leaf text-emerald-400"></i> {item.carbonSaved}kg Saved
                   </div>
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-black text-slate-900 leading-tight uppercase tracking-tight text-xs pr-2">{item.title}</h3>
                  <span className="text-sm font-black text-slate-900 whitespace-nowrap">₹{item.price}</span>
                </div>
                
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{item.owner}</span>
                  <div className="w-1 h-1 bg-slate-200 rounded-full"></div>
                  <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest">{item.department}</span>
                </div>

                <p className="text-slate-500 text-[10px] font-medium mt-4 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>

                <div className="mt-auto pt-6 border-t border-slate-50 flex justify-between items-center">
                   <div className="flex items-center gap-1 text-[8px] font-black text-emerald-600 uppercase tracking-wider">
                      <i className="fas fa-shield-check"></i> Verified Asset
                   </div>
                   <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-slate-900 group-hover:text-white transition-all">
                      <i className="fas fa-chevron-right text-[10px]"></i>
                   </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default Marketplace;
