
import { MarketplaceItem, Category, StudyNote } from './types';

export const BVDU_COORDINATES = {
  latitude: 18.4575,
  longitude: 73.8508
};

export const CENTRAL_LIBRARY_COORDINATES = {
  latitude: 18.4578,
  longitude: 73.8502
};

export const HANDOVER_DISTANCE_THRESHOLD_METERS = 100;

const DEMO_PDF_URL = 'https://www.africau.edu/images/default/sample.pdf';

export const MOCK_ITEMS: MarketplaceItem[] = [
  {
    id: 'm102',
    title: 'Casio fx-991EX Classwiz Scientific Calculator',
    imagePrompt: "Create a realistic, high-quality studio photo of a black Casio fx-991EX Classwiz Scientific Calculator. The item should be isolated on a clean white background.",
    description: 'Essential engineering tool for BVDU students. Features high-resolution ClassWiz display, spreadsheet functionality, and 552 functions. Permitted in all university exams.',
    price: 1150,
    listingType: 'Sell',
    category: Category.GENERAL_ESSENTIALS,
    department: '1st Year (General)',
    owner: 'Arjun S.',
    ownerEmail: 'arjun.s@bvuniversity.edu.in',
    ownerKarma: 145,
    imageUrl: 'https://images.unsplash.com/photo-1574607383476-f517f220d35a?q=80&w=1200&auto=format&fit=crop',
    condition: 'Excellent',
    createdAt: 'Just now',
    carbonSaved: 0.6
  },
  {
    id: 'm103',
    title: 'Professional Mini-Drafter (EG Kit)',
    imagePrompt: "Create a realistic, high-quality studio photo of a mechanical engineering Mini-Drafter tool. Isolated on a plain white background.",
    description: 'High-precision drafting tool essential for Engineering Graphics (EG) labs. Features smooth movement mechanism, stainless steel rods, and clear 360-degree scale markings.',
    price: 850,
    listingType: 'Sell',
    category: Category.ENGINEERING_GRAPHICS_KITS,
    department: 'Mechanical',
    owner: 'Priya K.',
    ownerEmail: 'priya.k@bvuniversity.edu.in',
    ownerKarma: 110,
    imageUrl: 'https://images.unsplash.com/photo-1503387762-592dee58c460?q=80&w=1200&auto=format&fit=crop',
    condition: 'Excellent',
    createdAt: '12m ago',
    carbonSaved: 1.4
  },
  {
    id: 'm107',
    title: 'Digital Multimeter with Probes',
    imagePrompt: "A yellow and black digital multimeter with test leads, isolated on white background, sharp focus.",
    description: 'High-accuracy digital multimeter for circuit testing. Auto-ranging with large LCD. Essential for E&TC and Robotics project work (PBL).',
    price: 550,
    listingType: 'Sell',
    category: Category.COMPONENTS,
    department: 'E&TC',
    owner: 'Aditi R.',
    ownerEmail: 'aditi.r@bvuniversity.edu.in',
    ownerKarma: 160,
    imageUrl: 'https://images.unsplash.com/photo-1590372873875-ed236b289053?q=80&w=1200&auto=format&fit=crop',
    condition: 'Excellent',
    createdAt: '1h ago',
    carbonSaved: 0.4
  },
  {
    id: 'm104',
    title: 'Arduino Uno R3 Starter Kit',
    imagePrompt: 'Create a high-quality, professional realistic photo of an Arduino Uno R3 board. Isolated on white background.',
    description: 'Authentic Arduino Uno R3 board with high-quality headers. Perfect for IT/CS and E&TC PBL projects. Fully tested and verified by technical audit.',
    price: 450,
    listingType: 'Sell',
    category: Category.COMPONENTS,
    department: 'IT',
    owner: 'Sneha M.',
    ownerEmail: 'sneha.m@bvuniversity.edu.in',
    ownerKarma: 140,
    imageUrl: 'https://images.unsplash.com/photo-1553406830-ef2513450d76?q=80&w=800&auto=format&fit=crop',
    condition: 'Like New',
    createdAt: '3h ago',
    carbonSaved: 0.3
  },
  {
    id: 'm108',
    title: 'Imperial Drawing Board (A3 Size)',
    imagePrompt: "A professional wooden drawing board with clips, clean white background, top view.",
    description: 'Standard size A3 drawing board for engineering students. Smooth surface with sturdy wooden base. Ideal for first-year graphics assignments.',
    price: 300,
    listingType: 'Free',
    category: Category.ENGINEERING_GRAPHICS_KITS,
    department: '1st Year (General)',
    owner: 'Siddharth P.',
    ownerEmail: 'sid.p@bvuniversity.edu.in',
    ownerKarma: 85,
    imageUrl: 'https://images.unsplash.com/photo-1516962215378-7fa2e137ae93?q=80&w=1200&auto=format&fit=crop',
    condition: 'Used',
    createdAt: '5h ago',
    carbonSaved: 2.1
  }
];

export const MOCK_NOTES: StudyNote[] = [
  {
    id: 'n1',
    title: 'Applied Mathematics - III (M3) Full Notes',
    subject: 'M3',
    department: 'Computer',
    semester: 3,
    author: 'Prof. G.B. Joshi',
    authorEmail: 'admin@bvuniversity.edu.in',
    isAuthorVerified: true,
    fileUrl: DEMO_PDF_URL,
    format: 'PDF (Softcopy)',
    downloads: 512,
    summary: 'Comprehensive notes covering Laplace Transforms, Fourier Series, and Complex Variables. Includes solved question papers from previous University exams.',
    imageUrl: ''
  },
  {
    id: 'n2',
    title: 'DSA: Handwritten Diagrams & Algos',
    subject: 'DSA',
    department: 'IT',
    semester: 3,
    author: 'Janhvi',
    authorEmail: 'janhvi@bvuniversity.edu.in',
    isAuthorVerified: true,
    fileUrl: DEMO_PDF_URL,
    format: 'Hardcopy (Handwritten)',
    downloads: 124,
    summary: 'Clean, color-coded notes for Trees, Graphs, and Sorting algorithms. Easy to understand diagrams for Unit Test prep.',
    imageUrl: ''
  }
];
